const { S3Client, GetObjectCommand, HeadObjectCommand, PutObjectCommand, CreateMultipartUploadCommand, UploadPartCommand, CompleteMultipartUploadCommand, AbortMultipartUploadCommand } = require("@aws-sdk/client-s3");
const { ReadStream, lstatSync, existsSync, createReadStream } = require("node:fs");
const { stat, opendir, realpath } = require("node:fs/promises");
const path = require("node:path");
const { resolve, join, relative, sep } = require("node:path");
const { Buffer: Buffer$1 } = require("buffer");
const { isReadableStream, sdkStreamMixin } = require("@smithy/core/serde");
const { Readable } = require("node:stream");
const { HttpResponse } = require("@smithy/core/protocols");
const { NodeHttpHandler } = require("@smithy/node-http-handler");
const { cpus } = require("node:os");
const { Worker } = require("node:worker_threads");

const byteLength = (input) => {
    if (input == null) {
        return 0;
    }
    if (typeof input === "string") {
        return Buffer$1.byteLength(input);
    }
    if (typeof input.byteLength === "number") {
        return input.byteLength;
    }
    else if (typeof input.length === "number") {
        return input.length;
    }
    else if (typeof input.size === "number") {
        return input.size;
    }
    else if (typeof input.start === "number" && typeof input.end === "number") {
        return input.end + 1 - input.start;
    }
    else if (input instanceof ReadStream) {
        try {
            return lstatSync(input.path).size;
        }
        catch {
            return undefined;
        }
    }
    return undefined;
};
async function* getChunkStream(data, partSize, getNextData) {
    let partNumber = 1;
    const currentBuffer = { chunks: [], length: 0 };
    for await (const datum of getNextData(data)) {
        currentBuffer.chunks.push(datum);
        currentBuffer.length += datum.byteLength;
        while (currentBuffer.length > partSize) {
            const dataChunk = currentBuffer.chunks.length > 1 ? Buffer$1.concat(currentBuffer.chunks) : currentBuffer.chunks[0];
            yield { partNumber, data: dataChunk.subarray(0, partSize) };
            currentBuffer.chunks = [dataChunk.subarray(partSize)];
            currentBuffer.length = currentBuffer.chunks[0].byteLength;
            partNumber += 1;
        }
    }
    yield {
        partNumber,
        data: currentBuffer.chunks.length !== 1 ? Buffer$1.concat(currentBuffer.chunks) : currentBuffer.chunks[0],
        lastPart: true,
    };
}
async function* getChunkUint8Array(data, partSize) {
    let partNumber = 1;
    let startByte = 0;
    let endByte = partSize;
    while (endByte < data.byteLength) {
        yield { partNumber, data: data.subarray(startByte, endByte) };
        partNumber += 1;
        startByte = endByte;
        endByte = startByte + partSize;
    }
    yield { partNumber, data: data.subarray(startByte), lastPart: true };
}
async function* getDataReadable(data) {
    for await (const chunk of data) {
        if (Buffer$1.isBuffer(chunk) || chunk instanceof Uint8Array) {
            yield chunk;
        }
        else {
            yield Buffer$1.from(chunk);
        }
    }
}
async function* getDataReadableStream(data) {
    const reader = data.getReader();
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                return;
            if (Buffer$1.isBuffer(value) || value instanceof Uint8Array) {
                yield value;
            }
            else {
                yield Buffer$1.from(value);
            }
        }
    }
    finally {
        reader.releaseLock();
    }
}
const getChunk = (data, partSize) => {
    if (data instanceof Uint8Array) {
        return getChunkUint8Array(data, partSize);
    }
    if (data instanceof String || typeof data === "string") {
        return getChunkUint8Array(Buffer$1.from(data), partSize);
    }
    if (data instanceof ReadableStream) {
        return getChunkStream(data, partSize, getDataReadableStream);
    }
    if (typeof data.stream === "function") {
        return getChunkStream(data.stream(), partSize, getDataReadableStream);
    }
    if (Symbol.asyncIterator in data || typeof data[Symbol.asyncIterator] === "function") {
        return getChunkStream(data, partSize, getDataReadable);
    }
    throw new Error("Body Data is unsupported format, expected data to be one of: string | Uint8Array | Buffer | Readable | ReadableStream | Blob;.");
};

class Semaphore {
    limit;
    inFlightRequests = 0;
    waiters = [];
    constructor(limit) {
        this.limit = limit;
    }
    async acquire(count = 1) {
        if (this.inFlightRequests < this.limit) {
            this.inFlightRequests += count;
            return;
        }
        await new Promise((resolve) => this.waiters.push(resolve));
        this.inFlightRequests += count;
    }
    release(count = 1) {
        this.inFlightRequests -= count;
        while (this.waiters.length > 0 && this.inFlightRequests < this.limit) {
            const next = this.waiters.shift();
            if (next) {
                next();
            }
        }
    }
}
async function validateDirectory(dirPath) {
    const absolutePath = resolve(dirPath);
    let stats;
    try {
        stats = await stat(absolutePath);
    }
    catch (error) {
        throw new Error(`Cannot access directory at: ${absolutePath}, ${error.message}`);
    }
    if (!stats.isDirectory()) {
        throw new Error(`Path is not a directory: ${absolutePath}`);
    }
    return absolutePath;
}
async function handleFailure(policy, context, abortController) {
    if (policy === "terminate") {
        abortController.abort();
        return "terminate";
    }
    if (policy === "continue") {
        return "continue";
    }
    try {
        const result = await policy(context);
        if (result === "terminate") {
            abortController.abort();
        }
        return result;
    }
    catch {
        abortController.abort();
        return "terminate";
    }
}

async function joinStreams(streams, eventListeners) {
    const firstStream = await streams[0];
    if (isReadableStream(firstStream)) {
        const newReadableStream = new ReadableStream({
            async start(controller) {
                for await (const chunk of iterateStreams(streams, eventListeners)) {
                    controller.enqueue(chunk);
                }
                controller.close();
            },
        });
        return sdkStreamMixin(newReadableStream);
    }
    else {
        streams.forEach((stream) => stream?.catch(() => { }));
        return sdkStreamMixin(Readable.from(iterateStreams(streams, eventListeners)));
    }
}
async function* iterateStreams(promises, eventListeners) {
    for (const p of promises) {
        p?.catch(() => { });
    }
    let bytesTransferred = 0;
    let index = 0;
    for (const streamPromise of promises) {
        if (!streamPromise) {
            throw new Error("Stream promise is undefined - lazy prefetch may not have completed");
        }
        let stream;
        try {
            stream = await streamPromise;
        }
        catch (e) {
            await destroyStreams(promises);
            eventListeners?.onFailure?.(e, index);
            throw e;
        }
        if (isReadableStream(stream)) {
            const reader = stream.getReader();
            try {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        break;
                    }
                    yield value;
                    bytesTransferred += value.byteLength;
                    eventListeners?.onBytes?.(bytesTransferred, index);
                }
            }
            catch (e) {
                await destroyStreams(promises);
                eventListeners?.onFailure?.(e, index);
                throw e;
            }
            finally {
                reader.releaseLock();
            }
        }
        else if (stream instanceof Readable) {
            try {
                for await (const chunk of stream) {
                    yield chunk;
                    const chunkSize = Buffer.isBuffer(chunk) ? chunk.length : Buffer.byteLength(chunk);
                    bytesTransferred += chunkSize;
                    eventListeners?.onBytes?.(bytesTransferred, index);
                }
            }
            catch (e) {
                await destroyStreams(promises);
                eventListeners?.onFailure?.(e, index);
                throw e;
            }
        }
        else {
            await destroyStreams(promises);
            const failure = new Error(`unhandled stream type ${stream?.constructor?.name}`);
            eventListeners?.onFailure?.(failure, index);
            throw failure;
        }
        eventListeners?.onStreamConsumed?.(index);
        index++;
    }
    eventListeners?.onCompletion?.(bytesTransferred, index - 1);
}
async function destroyStreams(promises) {
    await Promise.all(promises.map(async (streamPromise) => {
        if (!streamPromise)
            return;
        return streamPromise
            .then((stream) => {
            if (stream instanceof Readable) {
                stream.on("error", () => { });
                stream.destroy();
                return;
            }
            else if (isReadableStream(stream)) {
                return stream.cancel();
            }
        })
            .catch((e) => { });
    }));
}

class LogLevel {
    minimum;
    logger;
    static LEVELS = ["trace", "debug", "info", "warn", "error"];
    level = 5;
    constructor(minimum, logger = console) {
        this.minimum = minimum;
        this.logger = logger;
        const index = LogLevel.LEVELS.indexOf(minimum);
        if (index === -1) {
            throw new Error(`Log level must be one of ${LogLevel.LEVELS.join(", ")}`);
        }
        this.level = index;
    }
    trace(...args) {
        this.level <= 0 && this.logger.trace?.(...args);
    }
    debug(...args) {
        this.level <= 1 && this.logger.debug?.(...args);
    }
    info(...args) {
        this.level <= 2 && this.logger.info?.(...args);
    }
    warn(...args) {
        this.level <= 3 && this.logger.warn?.(...args);
    }
    error(...args) {
        this.level <= 4 && this.logger.error?.(...args);
    }
}

function createEmptyReadable() {
    return new Readable({
        read() {
            this.push(null);
        },
    });
}
function defaultWorkerCount() {
    return cpus().length;
}
class WorkerHttpHandler {
    workers = [];
    inflightRequests = new Map();
    nextRequestId = 0;
    workerInflightCounts = [];
    workerThreadCount;
    maxConcurrentUploads;
    initialized = false;
    initPromise;
    fallbackHandler;
    metadata = { handlerProtocol: "http/1.1" };
    constructor(options) {
        this.workerThreadCount = options?.workerThreadCount ?? defaultWorkerCount();
        this.maxConcurrentUploads = options?.maxConcurrentUploads ?? 32;
        this.fallbackHandler = new NodeHttpHandler();
    }
    resolveWorkerConfig() {
        const submodulePath = path.join(__dirname, "..", "worker", "index.js");
        if (existsSync(submodulePath)) {
            return { workerPath: submodulePath };
        }
        const tsPath = path.join(__dirname, "..", "worker", "index.ts");
        if (existsSync(tsPath)) {
            return { workerPath: tsPath, workerOptions: { execArgv: ["--require", "tsx/cjs"] } };
        }
        return { workerPath: submodulePath };
    }
    ensureInitialized() {
        if (this.initialized)
            return Promise.resolve();
        if (this.initPromise)
            return this.initPromise;
        this.initPromise = new Promise((resolve, reject) => {
            const { workerPath, workerOptions } = this.resolveWorkerConfig();
            let readyCount = 0;
            let errorCount = 0;
            let settled = false;
            this.workerInflightCounts = new Array(this.workerThreadCount).fill(0);
            for (let i = 0; i < this.workerThreadCount; i++) {
                const worker = new Worker(workerPath, workerOptions);
                this.workers.push(worker);
                const workerIndex = i;
                worker.on("message", (msg) => {
                    if (msg.type === "ready") {
                        worker.postMessage({
                            type: "config",
                            maxSockets: Math.max(50, this.maxConcurrentUploads),
                        });
                        readyCount++;
                        if (!settled && readyCount === this.workerThreadCount) {
                            settled = true;
                            this.initialized = true;
                            resolve();
                        }
                        return;
                    }
                    if (msg.type === "httpResponse") {
                        const pending = this.inflightRequests.get(msg.id);
                        this.inflightRequests.delete(msg.id);
                        if (pending) {
                            this.workerInflightCounts[pending.workerIndex]--;
                            pending.resolve({
                                response: new HttpResponse({
                                    statusCode: msg.response.statusCode,
                                    headers: msg.response.headers,
                                    body: msg.response.body,
                                }),
                            });
                        }
                        return;
                    }
                    if (msg.type === "httpError") {
                        const pending = this.inflightRequests.get(msg.id);
                        this.inflightRequests.delete(msg.id);
                        if (pending) {
                            this.workerInflightCounts[pending.workerIndex]--;
                            const error = Object.assign(new Error(msg.error), {
                                ...(msg.code && { code: msg.code }),
                                ...(msg.name && { name: msg.name }),
                            });
                            pending.reject(error);
                        }
                        return;
                    }
                });
                worker.on("error", (err) => {
                    if (!settled) {
                        errorCount++;
                        if (errorCount + readyCount === this.workerThreadCount) {
                            settled = true;
                            this.initPromise = undefined;
                            reject(new Error(`Failed to initialize worker threads: ${err.message}`));
                        }
                    }
                    for (const [id, pending] of this.inflightRequests) {
                        if (pending.workerIndex === workerIndex) {
                            pending.reject(err);
                            this.inflightRequests.delete(id);
                        }
                    }
                    this.workerInflightCounts[workerIndex] = Infinity;
                });
            }
        });
        return this.initPromise;
    }
    pickWorkerIndex() {
        let minIndex = 0;
        for (let i = 1; i < this.workerInflightCounts.length; i++) {
            if (this.workerInflightCounts[i] < this.workerInflightCounts[minIndex]) {
                minIndex = i;
            }
        }
        return minIndex;
    }
    dispatchToWorker(id, message) {
        const workerIndex = this.pickWorkerIndex();
        this.workerInflightCounts[workerIndex]++;
        return new Promise((resolve, reject) => {
            this.inflightRequests.set(id, { resolve, reject, workerIndex });
            this.workers[workerIndex].postMessage(message);
        });
    }
    extractPartNumber(request) {
        const partNumber = request.query?.partNumber;
        if (partNumber) {
            return Number(Array.isArray(partNumber) ? partNumber[0] : partNumber);
        }
        return undefined;
    }
    async handle(request, options) {
        const dataSource = options?.dataSource;
        const partNumber = this.extractPartNumber(request);
        if (!dataSource || !partNumber) {
            return this.fallbackHandler.handle(request, options);
        }
        await this.ensureInitialized();
        const id = this.nextRequestId++;
        const serializedRequest = {
            method: request.method,
            protocol: request.protocol,
            hostname: request.hostname,
            port: request.port,
            path: request.path,
            query: request.query,
            headers: request.headers,
        };
        if (dataSource.type === "file") {
            const { filePath, partSize, totalFileSize, checksumAlgorithm, checksumHeader } = dataSource;
            const offset = (partNumber - 1) * partSize;
            const length = Math.min(partSize, totalFileSize - offset);
            const message = {
                type: "httpRequestFromFile",
                id,
                request: serializedRequest,
                filePath,
                offset,
                length,
                checksumAlgorithm,
                checksumHeader,
            };
            return this.dispatchToWorker(id, message);
        }
        const { sharedBuffer, partSize, totalSize, checksumAlgorithm, checksumHeader } = dataSource;
        const offset = (partNumber - 1) * partSize;
        const length = Math.min(partSize, totalSize - offset);
        const message = {
            type: "httpRequestFromRAM",
            id,
            request: serializedRequest,
            sharedBuffer,
            offset,
            length,
            checksumAlgorithm,
            checksumHeader,
        };
        return this.dispatchToWorker(id, message);
    }
    updateHttpClientConfig(_key, _value) { }
    httpHandlerConfigs() {
        return {};
    }
    destroy() {
        for (const worker of this.workers) {
            worker.postMessage({ type: "done" });
        }
        this.workers = [];
        this.workerInflightCounts = [];
        this.initialized = false;
        this.initPromise = undefined;
        this.fallbackHandler.destroy();
    }
}

class S3TransferManager {
    static MIN_PART_SIZE = 5 * 1024 * 1024;
    s3;
    targetPartSizeBytes;
    multipartUploadThresholdBytes;
    requestChecksumCalculation;
    responseChecksumValidation;
    multipartDownloadType;
    eventListeners;
    abortCleanupFunctions = new WeakMap();
    maxConcurrentDownloads;
    maxConcurrentUploads;
    workerThreadCount;
    workerHttpHandler;
    logger;
    constructor(config = {}) {
        this.requestChecksumCalculation = config.requestChecksumCalculation ?? "WHEN_SUPPORTED";
        this.responseChecksumValidation = config.responseChecksumValidation ?? "WHEN_SUPPORTED";
        this.maxConcurrentUploads = config.maxConcurrentUploads ?? 32;
        this.workerThreadCount = config.workerThreadCount ?? defaultWorkerCount();
        this.s3 =
            config.s3 ??
                new S3Client({
                    requestChecksumCalculation: this.requestChecksumCalculation,
                    responseChecksumValidation: this.responseChecksumValidation,
                });
        if (this.workerThreadCount > 1) {
            this.workerHttpHandler = new WorkerHttpHandler({
                workerThreadCount: this.workerThreadCount,
                maxConcurrentUploads: this.maxConcurrentUploads,
            });
            if (this.s3.config) {
                this.s3.config.requestHandler = this.workerHttpHandler;
            }
        }
        this.targetPartSizeBytes = config.targetPartSizeBytes ?? 8 * 1024 * 1024;
        this.multipartUploadThresholdBytes = config.multipartUploadThresholdBytes ?? 16 * 1024 * 1024;
        this.multipartDownloadType = config.multipartDownloadType ?? "PART";
        this.maxConcurrentDownloads = config.maxConcurrentDownloads ?? 8;
        this.logger = config.logger ?? new LogLevel("warn");
        this.eventListeners = {
            transferInitiated: config.eventListeners?.transferInitiated ?? [],
            bytesTransferred: config.eventListeners?.bytesTransferred ?? [],
            transferComplete: config.eventListeners?.transferComplete ?? [],
            transferFailed: config.eventListeners?.transferFailed ?? [],
        };
        this.validateConfig();
    }
    addEventListener(type, callback, options) {
        const eventType = type;
        const listeners = this.eventListeners[eventType];
        if (!listeners) {
            throw new Error(`Unknown event type: ${eventType}`);
        }
        const once = typeof options !== "boolean" && options?.once;
        const signal = typeof options !== "boolean" ? options?.signal : undefined;
        let updatedCallback = callback;
        if (signal?.aborted) {
            return;
        }
        if (signal) {
            const removeListenerAfterAbort = () => {
                this.removeEventListener(eventType, updatedCallback);
                this.abortCleanupFunctions.delete(signal);
            };
            this.abortCleanupFunctions.set(signal, () => signal.removeEventListener("abort", removeListenerAfterAbort));
            signal.addEventListener("abort", removeListenerAfterAbort, { once: true });
        }
        if (once) {
            updatedCallback = (event) => {
                if (typeof callback === "function") {
                    callback(event);
                }
                else {
                    callback.handleEvent(event);
                }
                this.removeEventListener(eventType, updatedCallback);
            };
        }
        listeners.push(updatedCallback);
    }
    dispatchEvent(event) {
        const eventType = event.type;
        const listeners = this.eventListeners[eventType];
        if (listeners) {
            for (const listener of listeners) {
                if (typeof listener === "function") {
                    listener(event);
                }
                else {
                    listener.handleEvent(event);
                }
            }
        }
        return true;
    }
    removeEventListener(type, callback, options) {
        const eventType = type;
        const listeners = this.eventListeners[eventType];
        if (listeners) {
            if (eventType === "transferInitiated" ||
                eventType === "bytesTransferred" ||
                eventType === "transferFailed" ||
                eventType === "transferComplete") {
                const eventListener = callback;
                let index = listeners.indexOf(eventListener);
                while (index !== -1) {
                    listeners.splice(index, 1);
                    index = listeners.indexOf(eventListener);
                }
            }
            else {
                throw new Error(`Unknown event type: ${type}`);
            }
        }
    }
    async upload(request, transferOptions) {
        const totalContentLength = request.ContentLength ?? byteLength(request.Body);
        if (totalContentLength === undefined) {
            throw new Error("Unable to determine content length for upload");
        }
        this.checkAborted(transferOptions);
        this.addEventListeners(transferOptions?.eventListeners);
        this.dispatchTransferInitiatedEvent(request, totalContentLength);
        const removeLocalEventListeners = () => {
            this.removeEventListeners(transferOptions?.eventListeners);
            if (transferOptions?.abortSignal) {
                this.abortCleanupFunctions.get(transferOptions.abortSignal)?.();
                this.abortCleanupFunctions.delete(transferOptions.abortSignal);
            }
        };
        try {
            let response;
            if (totalContentLength < this.multipartUploadThresholdBytes) {
                response = await this.uploadSinglePart(request, totalContentLength, transferOptions);
            }
            else if (this.workerThreadCount > 1 && this.isFileBody(request.Body)) {
                response = await this.threadedUploadInPartsFromFile(request, totalContentLength, transferOptions);
            }
            else if (this.workerThreadCount > 1 && this.isInMemoryBody(request.Body)) {
                if (typeof request.Body === "string") {
                    request = { ...request, Body: new TextEncoder().encode(request.Body) };
                }
                response = await this.threadedUploadInParts(request, totalContentLength, transferOptions);
            }
            else {
                response = await this.uploadInParts(request, totalContentLength, transferOptions);
            }
            this.dispatchEvent(Object.assign(new Event("transferComplete"), {
                request,
                response,
                snapshot: {
                    transferredBytes: totalContentLength,
                    totalBytes: totalContentLength,
                },
            }));
            removeLocalEventListeners();
            return response;
        }
        catch (error) {
            this.dispatchTransferFailedEvent(request, totalContentLength, error);
            removeLocalEventListeners();
            throw error;
        }
    }
    async download(request, transferOptions) {
        const partNumber = request.PartNumber;
        if (typeof partNumber === "number") {
            throw new Error("partNumber included: S3 Transfer Manager does not support downloads for specific parts. Use GetObjectCommand instead");
        }
        const metadata = {};
        const streams = [];
        const requests = [];
        let totalSize;
        this.checkAborted(transferOptions);
        this.addEventListeners(transferOptions?.eventListeners);
        const checksumValidationEnabled = request.ChecksumMode === "ENABLED" || this.responseChecksumValidation === "WHEN_SUPPORTED";
        let onStreamConsumed;
        const removeLocalEventListeners = () => {
            this.removeEventListeners(transferOptions?.eventListeners);
            if (transferOptions?.abortSignal) {
                this.abortCleanupFunctions.get(transferOptions.abortSignal)?.();
                this.abortCleanupFunctions.delete(transferOptions.abortSignal);
            }
        };
        try {
            if (this.multipartDownloadType === "PART") {
                const responseMetadata = await this.downloadByPart(request, transferOptions ?? {}, streams, requests, metadata, checksumValidationEnabled);
                totalSize = responseMetadata.totalSize;
                onStreamConsumed = responseMetadata.onStreamConsumed;
            }
            else if (this.multipartDownloadType === "RANGE") {
                const responseMetadata = await this.downloadByRange(request, transferOptions ?? {}, streams, requests, metadata, checksumValidationEnabled);
                totalSize = responseMetadata.totalSize;
                onStreamConsumed = responseMetadata.onStreamConsumed;
            }
        }
        catch (error) {
            await destroyStreams(streams);
            removeLocalEventListeners();
            throw error;
        }
        const response = {
            ...metadata,
            Body: await joinStreams(streams, {
                onBytes: (byteLength, index) => {
                    this.dispatchEvent(Object.assign(new Event("bytesTransferred"), {
                        request: requests[index],
                        snapshot: {
                            transferredBytes: byteLength,
                            totalBytes: totalSize,
                        },
                    }));
                },
                onCompletion: (byteLength, index) => {
                    this.dispatchEvent(Object.assign(new Event("transferComplete"), {
                        request: requests[index],
                        response,
                        snapshot: {
                            transferredBytes: byteLength,
                            totalBytes: totalSize,
                        },
                    }));
                    removeLocalEventListeners();
                },
                onFailure: (error, index) => {
                    this.dispatchEvent(Object.assign(new Event("transferFailed"), {
                        request: requests[index],
                        snapshot: {
                            transferredBytes: error,
                            totalBytes: totalSize,
                        },
                    }));
                    removeLocalEventListeners();
                },
                onStreamConsumed,
            }),
        };
        return response;
    }
    async uploadDirectory(request, transferOptions) {
        const absoluteSource = await validateDirectory(request.source);
        const maxConcurrency = request.maxConcurrency ?? 100;
        const failurePolicy = request.failurePolicy ?? "terminate";
        const semaphore = new Semaphore(maxConcurrency);
        const abortController = new AbortController();
        const inFlight = new Set();
        let objectsUploaded = 0;
        let objectsFailed = 0;
        let terminated = false;
        let terminationError;
        this.checkAborted(transferOptions);
        this.addEventListeners(transferOptions?.eventListeners);
        let transferredBytes = 0;
        let transferredFiles = 0;
        let totalFiles = undefined;
        let totalBytes = undefined;
        let traversalComplete = false;
        const removeLocalEventListeners = () => {
            this.removeEventListeners(transferOptions?.eventListeners);
        };
        this.dispatchEvent(Object.assign(new Event("transferInitiated"), {
            request,
            snapshot: { transferredBytes: 0, totalBytes: undefined, transferredFiles: 0, totalFiles: undefined },
        }));
        const userSignal = transferOptions?.abortSignal;
        if (userSignal) {
            userSignal.addEventListener("abort", () => abortController.abort(), { once: true });
        }
        let discoveredFiles = 0;
        let discoveredBytes = 0;
        for await (const filePath of this.traverseDirectory(absoluteSource, {
            recursive: request.recursive ?? false,
            followSymbolicLinks: request.followSymbolicLinks ?? false,
        })) {
            if (terminated || abortController.signal.aborted)
                break;
            this.checkAborted(transferOptions);
            if (request.filter) {
                const include = request.filter instanceof RegExp ? request.filter.test(filePath) : request.filter(filePath);
                if (!include)
                    continue;
            }
            const fileStat = await stat(filePath);
            discoveredFiles++;
            discoveredBytes += fileStat.size;
            const count = fileStat.size >= this.multipartUploadThresholdBytes
                ? Math.min(Math.ceil(fileStat.size / this.targetPartSizeBytes), this.maxConcurrentUploads)
                : 1;
            await semaphore.acquire(count);
            if (terminated || abortController.signal.aborted) {
                semaphore.release(count);
                break;
            }
            const task = (async () => {
                try {
                    const key = this.deriveS3Key(absoluteSource, filePath, request.s3Prefix);
                    let putRequest = {
                        Bucket: request.bucket,
                        Key: key,
                        Body: createReadStream(filePath),
                        ContentLength: fileStat.size,
                    };
                    if (request.uploadObjectRequestModifier) {
                        putRequest = request.uploadObjectRequestModifier(putRequest);
                    }
                    await this.upload(putRequest, { abortSignal: abortController.signal });
                    objectsUploaded++;
                    transferredFiles++;
                    transferredBytes += fileStat.size;
                    this.dispatchEvent(Object.assign(new Event("bytesTransferred"), {
                        request,
                        snapshot: {
                            transferredBytes,
                            totalBytes: traversalComplete ? totalBytes : undefined,
                            transferredFiles,
                            totalFiles: traversalComplete ? totalFiles : undefined,
                        },
                    }));
                }
                catch (error) {
                    if (terminated || abortController.signal.aborted) {
                        objectsFailed++;
                        return;
                    }
                    const context = {
                        request,
                        objectRequest: {
                            Bucket: request.bucket,
                            Key: this.deriveS3Key(absoluteSource, filePath, request.s3Prefix),
                        },
                        error,
                    };
                    const result = await handleFailure(failurePolicy, context, abortController);
                    if (result === "terminate") {
                        terminated = true;
                        if (!terminationError) {
                            terminationError = error;
                        }
                    }
                    objectsFailed++;
                }
                finally {
                    semaphore.release(count);
                }
            })();
            inFlight.add(task);
            task.finally(() => inFlight.delete(task));
        }
        traversalComplete = true;
        totalFiles = discoveredFiles;
        totalBytes = discoveredBytes;
        await Promise.allSettled([...inFlight]);
        if (terminated && terminationError) {
            this.dispatchEvent(Object.assign(new Event("transferFailed"), {
                request,
                snapshot: { transferredBytes, totalBytes, transferredFiles, totalFiles },
            }));
            removeLocalEventListeners();
            throw terminationError;
        }
        this.dispatchEvent(Object.assign(new Event("transferComplete"), {
            request,
            response: { objectsUploaded, objectsFailed },
            snapshot: { transferredBytes, totalBytes, transferredFiles, totalFiles },
        }));
        removeLocalEventListeners();
        return { objectsUploaded, objectsFailed };
    }
    downloadDirectory(request, transferOptions) {
        throw new Error("Method not implemented.");
    }
    async downloadByPart(request, transferOptions, streams, requests, metadata, checksumValidationEnabled) {
        let totalSize;
        let streamConsumedCallback;
        this.checkAborted(transferOptions);
        if (request.Range == null) {
            const initialPartRequest = {
                ...request,
                PartNumber: 1,
                ...(checksumValidationEnabled && { ChecksumMode: "ENABLED" }),
            };
            try {
                const initialPart = await this.s3.send(new GetObjectCommand(initialPartRequest), transferOptions);
                await internalEventHandler.afterInitialGetObject();
                const partSize = initialPart.ContentLength;
                const initialETag = initialPart.ETag ?? undefined;
                totalSize = initialPart.ContentRange ? Number.parseInt(initialPart.ContentRange.split("/")[1]) : 0;
                this.dispatchTransferInitiatedEvent(request, totalSize);
                if (initialPart.Body) {
                    if (initialPart.Body && typeof initialPart.Body.getReader === "function") {
                        const reader = initialPart.Body.getReader();
                        initialPart.Body.getReader = function () {
                            return reader;
                        };
                    }
                    streams.push(Promise.resolve(initialPart.Body));
                    requests.push(initialPartRequest);
                }
                this.processResponseMetadata(initialPart, metadata, totalSize);
                let partCount = 1;
                if (initialPart.PartsCount > 1) {
                    const partTasks = [];
                    const partRequests = [];
                    for (let part = 2; part <= initialPart.PartsCount; part++) {
                        const getObjectRequest = {
                            ...request,
                            PartNumber: part,
                            IfMatch: initialETag,
                            ...(checksumValidationEnabled && { ChecksumMode: "ENABLED" }),
                        };
                        partRequests.push(getObjectRequest);
                        partTasks.push(() => {
                            this.checkAborted(transferOptions);
                            return this.s3
                                .send(new GetObjectCommand(getObjectRequest), transferOptions)
                                .then((response) => {
                                this.validatePartDownload(response.ContentRange, part, partSize ?? 0);
                                if (response.Body && typeof response.Body.getReader === "function") {
                                    const reader = response.Body.getReader();
                                    response.Body.getReader = function () {
                                        return reader;
                                    };
                                }
                                return response.Body;
                            })
                                .catch((error) => {
                                this.dispatchTransferFailedEvent(getObjectRequest, totalSize, error);
                                throw error;
                            });
                        });
                    }
                    const { promises: pendingStreams, onStreamConsumed } = this.createConcurrentTaskPool(partTasks, this.maxConcurrentDownloads);
                    streams.push(...pendingStreams);
                    requests.push(...partRequests);
                    streamConsumedCallback = onStreamConsumed;
                    partCount += partTasks.length;
                    if (partCount !== initialPart.PartsCount) {
                        throw new Error(`The number of parts downloaded (${partCount}) does not match the expected number (${initialPart.PartsCount})`);
                    }
                }
            }
            catch (error) {
                this.dispatchTransferFailedEvent(request, totalSize, error);
                throw error;
            }
        }
        else {
            this.checkAborted(transferOptions);
            try {
                const getObjectRequest = {
                    ...request,
                    ...(checksumValidationEnabled && { ChecksumMode: "ENABLED" }),
                };
                const getObject = await this.s3.send(new GetObjectCommand(getObjectRequest), transferOptions);
                totalSize = getObject.ContentRange ? Number.parseInt(getObject.ContentRange.split("/")[1]) : 0;
                this.dispatchTransferInitiatedEvent(request, totalSize);
                if (getObject.Body) {
                    streams.push(Promise.resolve(getObject.Body));
                    requests.push(getObjectRequest);
                }
                this.processResponseMetadata(getObject, metadata, totalSize);
            }
            catch (error) {
                this.dispatchTransferFailedEvent(request, undefined, error);
                throw error;
            }
        }
        return {
            totalSize,
            onStreamConsumed: streamConsumedCallback,
        };
    }
    async downloadByRange(request, transferOptions, streams, requests, metadata, checksumValidationEnabled) {
        let streamConsumedCallback;
        this.checkAborted(transferOptions);
        const headResponse = await this.s3.send(new HeadObjectCommand({ Bucket: request.Bucket, Key: request.Key }), transferOptions);
        if (headResponse.ContentLength === 0) {
            const getObjectRequest = { ...request, ...(checksumValidationEnabled && { ChecksumMode: "ENABLED" }) };
            const response = await this.s3.send(new GetObjectCommand(getObjectRequest), transferOptions);
            this.dispatchTransferInitiatedEvent(request, 0);
            if (response.Body)
                streams.push(Promise.resolve(response.Body));
            requests.push(getObjectRequest);
            this.processResponseMetadata(response, metadata, 0);
            return { totalSize: 0 };
        }
        let left = 0;
        let right = this.targetPartSizeBytes - 1;
        let maxRange = Number.POSITIVE_INFINITY;
        let remainingLength = 1;
        let totalSize;
        let initialETag;
        if (request.Range != null) {
            const [userRangeLeft, userRangeRight] = request.Range.replace("bytes=", "").split("-").map(Number);
            maxRange = userRangeRight;
            left = userRangeLeft;
            right = Math.min(userRangeRight, left + S3TransferManager.MIN_PART_SIZE - 1);
            totalSize = userRangeRight + 1;
        }
        try {
            const getObjectRequest = {
                ...request,
                Range: `bytes=${left}-${right}`,
                ...(checksumValidationEnabled && { ChecksumMode: "ENABLED" }),
            };
            const initialRangeGet = await this.s3.send(new GetObjectCommand(getObjectRequest), transferOptions);
            await internalEventHandler.afterInitialGetObject();
            this.validateRangeDownload(`bytes=${left}-${right}`, initialRangeGet.ContentRange);
            initialETag = initialRangeGet.ETag ?? undefined;
            if (!totalSize) {
                totalSize = initialRangeGet.ContentRange
                    ? Number.parseInt(initialRangeGet.ContentRange.split("/")[1])
                    : undefined;
            }
            if (initialRangeGet.Body && typeof initialRangeGet.Body.getReader === "function") {
                const reader = initialRangeGet.Body.getReader();
                initialRangeGet.Body.getReader = function () {
                    return reader;
                };
            }
            this.dispatchTransferInitiatedEvent(request, totalSize);
            streams.push(Promise.resolve(initialRangeGet.Body));
            requests.push(getObjectRequest);
            this.processResponseMetadata(initialRangeGet, metadata, totalSize);
        }
        catch (error) {
            this.dispatchTransferFailedEvent(request, totalSize, error);
            throw error;
        }
        let expectedRequestCount = 1;
        if (totalSize) {
            const contentLength = totalSize;
            const remainingBytes = Math.max(0, contentLength - (right - left + 1));
            const additionalRequests = Math.ceil(remainingBytes / S3TransferManager.MIN_PART_SIZE);
            expectedRequestCount += additionalRequests;
        }
        left = right + 1;
        right = Math.min(left + S3TransferManager.MIN_PART_SIZE - 1, maxRange);
        remainingLength = totalSize ? Math.min(right - left + 1, Math.max(0, totalSize - left)) : 0;
        const rangeTasks = [];
        const rangeRequests = [];
        while (remainingLength > 0) {
            const range = `bytes=${left}-${right}`;
            const getObjectRequest = {
                ...request,
                Range: range,
                IfMatch: initialETag,
                ...(checksumValidationEnabled && { ChecksumMode: "ENABLED" }),
            };
            rangeRequests.push(getObjectRequest);
            rangeTasks.push(() => {
                this.checkAborted(transferOptions);
                return this.s3
                    .send(new GetObjectCommand(getObjectRequest), transferOptions)
                    .then((response) => {
                    this.validateRangeDownload(range, response.ContentRange);
                    if (response.Body && typeof response.Body.getReader === "function") {
                        const reader = response.Body.getReader();
                        response.Body.getReader = function () {
                            return reader;
                        };
                    }
                    return response.Body;
                })
                    .catch((error) => {
                    this.dispatchTransferFailedEvent(getObjectRequest, totalSize, error);
                    throw error;
                });
            });
            left = right + 1;
            right = Math.min(left + S3TransferManager.MIN_PART_SIZE - 1, maxRange);
            remainingLength = totalSize ? Math.min(right - left + 1, Math.max(0, totalSize - left)) : 0;
        }
        if (rangeTasks.length > 0) {
            const { promises: pendingStreams, onStreamConsumed } = this.createConcurrentTaskPool(rangeTasks, this.maxConcurrentDownloads);
            streams.push(...pendingStreams);
            requests.push(...rangeRequests);
            streamConsumedCallback = onStreamConsumed;
        }
        const actualRequestCount = 1 + rangeTasks.length;
        if (expectedRequestCount !== actualRequestCount) {
            throw new Error(`The number of ranged GET requests sent (${actualRequestCount}) does not match the expected number (${expectedRequestCount})`);
        }
        return {
            totalSize,
            onStreamConsumed: streamConsumedCallback,
        };
    }
    addEventListeners(eventListeners) {
        for (const listeners of this.iterateListeners(eventListeners)) {
            for (const listener of listeners) {
                this.addEventListener(listener.eventType, listener.callback);
            }
        }
    }
    removeEventListeners(eventListeners) {
        for (const listeners of this.iterateListeners(eventListeners)) {
            for (const listener of listeners) {
                this.removeEventListener(listener.eventType, listener.callback);
            }
        }
    }
    assignMetadata(container, response) {
        for (const key in response) {
            if (key === "Body") {
                continue;
            }
            container[key] = response[key];
        }
    }
    updateResponseLengthAndRange(response, totalSize) {
        if (totalSize !== undefined) {
            response.ContentLength = totalSize;
            response.ContentRange = `bytes 0-${totalSize - 1}/${totalSize}`;
        }
    }
    updateChecksumValues(initialPart, metadata) {
        if (initialPart.ChecksumType === "COMPOSITE") {
            metadata.ChecksumCRC32 = undefined;
            metadata.ChecksumCRC32C = undefined;
            metadata.ChecksumSHA1 = undefined;
            metadata.ChecksumSHA256 = undefined;
        }
    }
    processResponseMetadata(response, metadata, totalSize) {
        this.updateResponseLengthAndRange(response, totalSize);
        this.assignMetadata(metadata, response);
        this.updateChecksumValues(response, metadata);
    }
    checkAborted(transferOptions) {
        if (transferOptions?.abortSignal?.aborted) {
            throw Object.assign(new Error("Transfer aborted."), { name: "AbortError" });
        }
    }
    validateConfig() {
        if (this.targetPartSizeBytes < S3TransferManager.MIN_PART_SIZE) {
            throw new Error(`targetPartSizeBytes must be at least ${S3TransferManager.MIN_PART_SIZE} bytes`);
        }
    }
    dispatchTransferInitiatedEvent(request, totalSize) {
        this.dispatchEvent(Object.assign(new Event("transferInitiated"), {
            request,
            snapshot: {
                transferredBytes: 0,
                totalBytes: totalSize,
            },
        }));
        return true;
    }
    dispatchTransferFailedEvent(request, totalSize, error) {
        this.dispatchEvent(Object.assign(new Event("transferFailed"), {
            request,
            error,
            snapshot: {
                transferredBytes: 0,
                totalBytes: totalSize,
            },
        }));
        return true;
    }
    *iterateListeners(eventListeners = {}) {
        for (const key in eventListeners) {
            const eventType = key;
            const listeners = eventListeners[eventType];
            if (Array.isArray(listeners)) {
                for (const callback of listeners) {
                    yield [
                        {
                            eventType: eventType,
                            callback: callback,
                        },
                    ];
                }
            }
        }
    }
    createConcurrentTaskPool(tasks, maxConcurrent) {
        if (tasks.length === 0)
            return { promises: [], onStreamConsumed: () => { } };
        const resolvers = [];
        const promises = tasks.map(() => {
            let resolve;
            let reject;
            const promise = new Promise((res, rej) => {
                resolve = res;
                reject = rej;
            });
            resolvers.push({ resolve, reject });
            return promise;
        });
        let nextToLaunch = 0;
        let failed = false;
        const launchTask = (index) => {
            tasks[index]().then((result) => {
                resolvers[index].resolve(result);
            }, (error) => {
                failed = true;
                resolvers[index].reject(error);
            });
        };
        const initialBatch = Math.min(maxConcurrent, tasks.length);
        for (let i = 0; i < initialBatch; i++) {
            launchTask(nextToLaunch++);
        }
        const onStreamConsumed = (_index) => {
            if (failed || nextToLaunch >= tasks.length)
                return;
            launchTask(nextToLaunch++);
        };
        return { promises, onStreamConsumed };
    }
    validatePartDownload(contentRange, partNumber, partSize) {
        if (!contentRange) {
            throw new Error(`Missing ContentRange for part ${partNumber}.`);
        }
        const match = contentRange.match(/bytes (\d+)-(\d+)\/(\d+)/);
        if (!match)
            throw new Error(`Invalid ContentRange format: ${contentRange}`);
        const start = Number.parseInt(match[1]);
        const end = Number.parseInt(match[2]);
        const total = Number.parseInt(match[3]) - 1;
        const expectedStart = (partNumber - 1) * partSize;
        const expectedEnd = Math.min(expectedStart + partSize - 1, total);
        if (start !== expectedStart) {
            throw new Error(`Expected part ${partNumber} to start at ${expectedStart} but got ${start}`);
        }
        if (end !== expectedEnd) {
            throw new Error(`Expected part ${partNumber} to end at ${expectedEnd} but got ${end}`);
        }
    }
    validateRangeDownload(requestRange, responseRange) {
        if (!responseRange) {
            throw new Error(`Missing ContentRange for range ${requestRange}.`);
        }
        const match = responseRange.match(/bytes (\d+)-(\d+)\/(\d+)/);
        if (!match)
            throw new Error(`Invalid ContentRange format: ${responseRange}`);
        const start = Number.parseInt(match[1]);
        const end = Number.parseInt(match[2]);
        const total = Number.parseInt(match[3]) - 1;
        const rangeMatch = requestRange.match(/bytes=(\d+)-(\d+)/);
        if (!rangeMatch)
            throw new Error(`Invalid Range format: ${requestRange}`);
        const expectedStart = Number.parseInt(rangeMatch[1]);
        const expectedEnd = Number.parseInt(rangeMatch[2]);
        if (start !== expectedStart) {
            throw new Error(`Expected range to start at ${expectedStart} but got ${start}`);
        }
        if (end === expectedEnd) {
            return;
        }
        if (end === total) {
            return;
        }
        throw new Error(`Expected range to end at ${expectedEnd} but got ${end}`);
    }
    async uploadSinglePart(request, contentLength, transferOptions) {
        const putObjectRequest = { ...request };
        this.checkAborted(transferOptions);
        const response = await this.s3.send(new PutObjectCommand(putObjectRequest), transferOptions);
        this.dispatchEvent(Object.assign(new Event("bytesTransferred"), {
            request,
            snapshot: {
                transferredBytes: contentLength,
                totalBytes: contentLength,
            },
        }));
        return response;
    }
    calculatePartSize(contentLength) {
        const partSize = Math.max(this.targetPartSizeBytes, Math.ceil(contentLength / 10_000));
        const expectedPartsCount = Math.ceil(contentLength / partSize);
        return { partSize, expectedPartsCount };
    }
    isFileBody(body) {
        return typeof body?.pipe === "function" && typeof body.path === "string";
    }
    isInMemoryBody(body) {
        return body instanceof Uint8Array || typeof body === "string";
    }
    async threadedUploadInPartsFromFile(request, contentLength, transferOptions) {
        const { partSize } = this.calculatePartSize(contentLength);
        const filePath = request.Body.path;
        const buildDataSource = (checksumAlgorithm, checksumHeader) => ({
            type: "file",
            filePath,
            partSize,
            totalFileSize: contentLength,
            checksumAlgorithm,
            checksumHeader,
        });
        return this.threadedMultipartUpload(request, contentLength, buildDataSource, transferOptions);
    }
    async threadedUploadInParts(request, contentLength, transferOptions) {
        const { partSize } = this.calculatePartSize(contentLength);
        const body = request.Body;
        const sharedBuffer = new SharedArrayBuffer(body.byteLength);
        new Uint8Array(sharedBuffer).set(body);
        const buildDataSource = (checksumAlgorithm, checksumHeader) => ({
            type: "sharedBuffer",
            sharedBuffer,
            partSize,
            totalSize: contentLength,
            checksumAlgorithm,
            checksumHeader,
        });
        return this.threadedMultipartUpload(request, contentLength, buildDataSource, transferOptions);
    }
    async threadedMultipartUpload(request, contentLength, buildDataSource, transferOptions) {
        const { partSize, expectedPartsCount } = this.calculatePartSize(contentLength);
        this.checkAborted(transferOptions);
        const createMpuRequest = { ...request };
        const hasFullObjectChecksum = request.ContentMD5 ||
            request.ChecksumCRC32 ||
            request.ChecksumCRC32C ||
            request.ChecksumCRC64NVME ||
            request.ChecksumSHA1 ||
            request.ChecksumSHA256;
        if (hasFullObjectChecksum) {
            createMpuRequest.ChecksumType = "FULL_OBJECT";
        }
        if (!createMpuRequest.ChecksumAlgorithm && this.requestChecksumCalculation === "WHEN_SUPPORTED") {
            createMpuRequest.ChecksumAlgorithm = request.ChecksumAlgorithm ?? "CRC32";
        }
        const createMpuResponse = await this.s3.send(new CreateMultipartUploadCommand(createMpuRequest), transferOptions);
        const uploadId = createMpuResponse.UploadId;
        const checksumAlgorithm = createMpuRequest.ChecksumAlgorithm;
        const checksumHeader = checksumAlgorithm ? `x-amz-checksum-${checksumAlgorithm.toLowerCase()}` : undefined;
        const dataSource = buildDataSource(checksumAlgorithm, checksumHeader);
        try {
            const partQueue = [];
            for (let i = 1; i <= expectedPartsCount; i++)
                partQueue.push(i);
            const completedPartsArr = [];
            const uploadOnePart = async () => {
                while (partQueue.length > 0) {
                    const partNumber = partQueue.shift();
                    this.checkAborted(transferOptions);
                    const offset = (partNumber - 1) * partSize;
                    const length = Math.min(partSize, contentLength - offset);
                    const placeholderBody = createEmptyReadable();
                    const partRequest = {
                        ...request,
                        Body: placeholderBody,
                        UploadId: uploadId,
                        PartNumber: partNumber,
                        ContentLength: length,
                        ...(checksumAlgorithm && { ChecksumAlgorithm: checksumAlgorithm }),
                    };
                    const partResponse = await this.s3.send(new UploadPartCommand(partRequest), {
                        ...transferOptions,
                        dataSource,
                    });
                    completedPartsArr.push({ partNumber, response: partResponse });
                }
            };
            const lanes = Math.min(this.maxConcurrentUploads, expectedPartsCount);
            await Promise.all(Array.from({ length: lanes }, () => uploadOnePart()));
            const results = completedPartsArr;
            const completedParts = results.map(({ partNumber, response: partResponse }) => {
                const completedPart = {
                    PartNumber: partNumber,
                    ETag: partResponse.ETag,
                };
                if (partResponse.ChecksumCRC32)
                    completedPart.ChecksumCRC32 = partResponse.ChecksumCRC32;
                if (partResponse.ChecksumCRC32C)
                    completedPart.ChecksumCRC32C = partResponse.ChecksumCRC32C;
                if (partResponse.ChecksumCRC64NVME)
                    completedPart.ChecksumCRC64NVME = partResponse.ChecksumCRC64NVME;
                if (partResponse.ChecksumSHA1)
                    completedPart.ChecksumSHA1 = partResponse.ChecksumSHA1;
                if (partResponse.ChecksumSHA256)
                    completedPart.ChecksumSHA256 = partResponse.ChecksumSHA256;
                return completedPart;
            });
            if (completedParts.length !== expectedPartsCount) {
                throw new Error(`Expected ${expectedPartsCount} parts but uploaded ${completedParts.length} parts`);
            }
            completedParts.sort((a, b) => a.PartNumber - b.PartNumber);
            this.checkAborted(transferOptions);
            const { Body: _body, ...completeRequestFields } = request;
            const completeRequest = {
                ...completeRequestFields,
                UploadId: uploadId,
                MultipartUpload: { Parts: completedParts },
                MpuObjectSize: contentLength,
            };
            if (hasFullObjectChecksum) {
                completeRequest.ChecksumType = "FULL_OBJECT";
                if (request.ChecksumCRC32)
                    completeRequest.ChecksumCRC32 = request.ChecksumCRC32;
                if (request.ChecksumCRC32C)
                    completeRequest.ChecksumCRC32C = request.ChecksumCRC32C;
                if (request.ChecksumCRC64NVME)
                    completeRequest.ChecksumCRC64NVME = request.ChecksumCRC64NVME;
            }
            try {
                return await this.s3.send(new CompleteMultipartUploadCommand(completeRequest), transferOptions);
            }
            catch (completeMpuError) {
                this.logger.warn(`CompleteMultipartUpload failed for upload ID ${uploadId}: ${completeMpuError.message}`);
                throw completeMpuError;
            }
        }
        catch (error) {
            const { Body: _abortBody, ...abortRequestFields } = request;
            const abortRequest = {
                ...abortRequestFields,
                UploadId: uploadId,
            };
            try {
                await this.s3.send(new AbortMultipartUploadCommand(abortRequest), transferOptions);
            }
            catch (abortError) {
                this.logger.warn(`Failed to abort multipart upload ${uploadId}:`, abortError);
            }
            throw error;
        }
    }
    async uploadInParts(request, contentLength, transferOptions) {
        const { partSize, expectedPartsCount } = this.calculatePartSize(contentLength);
        this.checkAborted(transferOptions);
        const createMpuRequest = { ...request };
        const hasFullObjectChecksum = request.ContentMD5 ||
            request.ChecksumCRC32 ||
            request.ChecksumCRC32C ||
            request.ChecksumCRC64NVME ||
            request.ChecksumSHA1 ||
            request.ChecksumSHA256;
        if (hasFullObjectChecksum) {
            createMpuRequest.ChecksumType = "FULL_OBJECT";
        }
        if (!createMpuRequest.ChecksumAlgorithm && this.requestChecksumCalculation === "WHEN_SUPPORTED") {
            createMpuRequest.ChecksumAlgorithm = request.ChecksumAlgorithm ?? "CRC32";
        }
        const createMpuResponse = await this.s3.send(new CreateMultipartUploadCommand(createMpuRequest), transferOptions);
        const uploadId = createMpuResponse.UploadId;
        const abortController = new AbortController();
        const uploadAbortSignal = abortController.signal;
        try {
            const completedParts = [];
            const dataFeeder = getChunk(request.Body, partSize);
            let bytesUploaded = 0;
            const uploadPart = async (dataFeeder) => {
                for await (const dataPart of dataFeeder) {
                    if (uploadAbortSignal.aborted) {
                        throw Object.assign(new Error("Upload aborted due to part failure."), { name: "AbortError" });
                    }
                    this.checkAborted(transferOptions);
                    this.validateUploadPart(dataPart, partSize);
                    const partRequest = {
                        ...request,
                        Body: dataPart.data,
                        UploadId: uploadId,
                        PartNumber: dataPart.partNumber,
                        ContentLength: byteLength(dataPart.data),
                        ...(this.requestChecksumCalculation === "WHEN_SUPPORTED" && {
                            ChecksumAlgorithm: request.ChecksumAlgorithm,
                        }),
                    };
                    const partResponse = await this.s3.send(new UploadPartCommand(partRequest), transferOptions);
                    const checksumAlgorithm = partRequest.ChecksumAlgorithm;
                    if (checksumAlgorithm &&
                        !partResponse.ChecksumCRC32 &&
                        !partResponse.ChecksumCRC32C &&
                        !partResponse.ChecksumCRC64NVME &&
                        !partResponse.ChecksumSHA1 &&
                        !partResponse.ChecksumSHA256) {
                        throw new Error(`Checksum was requested for part ${dataPart.partNumber} using ${checksumAlgorithm}, but no checksum was returned in the response. ` +
                            `If running in a browser, ensure your S3 bucket CORS configuration is enabled. `);
                    }
                    const completedPart = {
                        PartNumber: dataPart.partNumber,
                        ETag: partResponse.ETag,
                    };
                    if (partResponse.ChecksumCRC32)
                        completedPart.ChecksumCRC32 = partResponse.ChecksumCRC32;
                    if (partResponse.ChecksumCRC32C)
                        completedPart.ChecksumCRC32C = partResponse.ChecksumCRC32C;
                    if (partResponse.ChecksumCRC64NVME)
                        completedPart.ChecksumCRC64NVME = partResponse.ChecksumCRC64NVME;
                    if (partResponse.ChecksumSHA1)
                        completedPart.ChecksumSHA1 = partResponse.ChecksumSHA1;
                    if (partResponse.ChecksumSHA256)
                        completedPart.ChecksumSHA256 = partResponse.ChecksumSHA256;
                    completedParts.push(completedPart);
                    const partLength = byteLength(dataPart.data);
                    bytesUploaded += partLength;
                    this.dispatchEvent(Object.assign(new Event("bytesTransferred"), {
                        request,
                        snapshot: {
                            transferredBytes: bytesUploaded,
                            totalBytes: contentLength,
                        },
                    }));
                }
            };
            const partUploads = [];
            for (let i = 0; i < this.maxConcurrentUploads; i++) {
                partUploads.push(uploadPart(dataFeeder).catch((error) => {
                    abortController.abort();
                    throw error;
                }));
            }
            await Promise.all(partUploads);
            if (completedParts.length !== expectedPartsCount) {
                throw new Error(`Expected ${expectedPartsCount} parts but uploaded ${completedParts.length} parts`);
            }
            completedParts.sort((a, b) => a.PartNumber - b.PartNumber);
            this.checkAborted(transferOptions);
            const { Body: _body, ...completeRequestFields } = request;
            const completeRequest = {
                ...completeRequestFields,
                UploadId: uploadId,
                MultipartUpload: { Parts: completedParts },
                MpuObjectSize: contentLength,
            };
            if (hasFullObjectChecksum) {
                completeRequest.ChecksumType = "FULL_OBJECT";
                if (request.ChecksumCRC32)
                    completeRequest.ChecksumCRC32 = request.ChecksumCRC32;
                if (request.ChecksumCRC32C)
                    completeRequest.ChecksumCRC32C = request.ChecksumCRC32C;
                if (request.ChecksumCRC64NVME)
                    completeRequest.ChecksumCRC64NVME = request.ChecksumCRC64NVME;
            }
            try {
                return await this.s3.send(new CompleteMultipartUploadCommand(completeRequest), transferOptions);
            }
            catch (completeMpuError) {
                this.logger.warn(`CompleteMultipartUpload failed for upload ID ${uploadId}: ${completeMpuError.message}`);
                throw completeMpuError;
            }
        }
        catch (error) {
            const { Body: _abortBody, ...abortRequestFields } = request;
            const abortRequest = {
                ...abortRequestFields,
                UploadId: uploadId,
            };
            try {
                await this.s3.send(new AbortMultipartUploadCommand(abortRequest), transferOptions);
            }
            catch (abortError) {
                this.logger.warn(`Failed to abort multipart upload ${uploadId}:`, abortError);
            }
            throw error;
        }
    }
    async *traverseDirectory(source, options) {
        const visited = new Set();
        const dir = await opendir(source, { recursive: options.recursive });
        for await (const entry of dir) {
            const fullPath = join(entry.parentPath ?? entry.path ?? source, entry.name);
            if (entry.isSymbolicLink()) {
                if (!options.followSymbolicLinks)
                    continue;
                const realPath = await realpath(fullPath);
                const linkStat = await stat(realPath);
                if (linkStat.isDirectory()) {
                    if (visited.has(realPath)) {
                        throw new Error(`Circular symbolic link detected: ${fullPath} -> ${realPath}`);
                    }
                    visited.add(realPath);
                    yield* this.traverseDirectory(realPath, options);
                    continue;
                }
                if (!linkStat.isFile())
                    continue;
            }
            else if (!entry.isFile()) {
                continue;
            }
            yield fullPath;
        }
    }
    deriveS3Key(source, filePath, s3Prefix) {
        let relativePath = relative(source, filePath);
        if (sep !== "/") {
            relativePath = relativePath.split(sep).join("/");
        }
        if (!s3Prefix)
            return relativePath;
        const normalizedPrefix = s3Prefix.endsWith("/") ? s3Prefix : s3Prefix + "/";
        return normalizedPrefix + relativePath;
    }
    validateUploadPart(dataPart, partSize) {
        const actualPartSize = byteLength(dataPart.data);
        if (actualPartSize === undefined) {
            throw new Error(`A dataPart was generated without a measurable data chunk size for part number ${dataPart.partNumber}`);
        }
        if (dataPart.partNumber === 1 && dataPart.lastPart) {
            return;
        }
        if (!dataPart.lastPart && actualPartSize !== partSize) {
            throw new Error(`The byte size for part number ${dataPart.partNumber}, size ${actualPartSize} does not match expected size ${partSize}`);
        }
    }
}
const internalEventHandler = {
    async afterInitialGetObject() { },
};

exports.S3TransferManager = S3TransferManager;
