const { HttpRequest } = require("@smithy/core/protocols");
const { NodeHttpHandler } = require("@smithy/node-http-handler");
const { open } = require("node:fs/promises");
const { Agent } = require("node:https");
const { parentPort } = require("node:worker_threads");
const { crc32 } = require("node:zlib");

function toBase64(n) {
    const buf = Buffer.allocUnsafe(4);
    buf.writeUInt32BE(n >>> 0, 0);
    return buf.toString("base64");
}
if (parentPort) {
    let handler;
    const port = parentPort;
    const readFileSlice = async (filePath, offset, length) => {
        const fh = await open(filePath, "r");
        try {
            const buffer = Buffer.allocUnsafe(length);
            await fh.read(buffer, 0, length, offset);
            return buffer;
        }
        finally {
            await fh.close();
        }
    };
    const buildAwsChunkedBody = (data, checksumHeader, checksumValue) => {
        const hexLen = data.byteLength.toString(16);
        const parts = [Buffer.from(`${hexLen}\r\n`), data, Buffer.from("\r\n0\r\n")];
        if (checksumHeader && checksumValue) {
            parts.push(Buffer.from(`${checksumHeader}:${checksumValue}\r\n`));
        }
        parts.push(Buffer.from("\r\n"));
        return Buffer.concat(parts);
    };
    const processRequest = async (msg) => {
        const { id, request: serialized } = msg;
        try {
            let body;
            if (msg.type === "httpRequestFromRAM") {
                const fileData = Buffer.from(msg.sharedBuffer, msg.offset, msg.length);
                if (msg.checksumAlgorithm && msg.checksumHeader) {
                    const crcValue = crc32(fileData);
                    const checksumValue = toBase64(crcValue);
                    body = buildAwsChunkedBody(fileData, msg.checksumHeader, checksumValue);
                }
                else {
                    body = fileData;
                }
            }
            else if (msg.type === "httpRequestFromFile") {
                const fileData = await readFileSlice(msg.filePath, msg.offset, msg.length);
                if (msg.checksumAlgorithm && msg.checksumHeader) {
                    const crcValue = crc32(fileData);
                    const checksumValue = toBase64(crcValue);
                    body = buildAwsChunkedBody(fileData, msg.checksumHeader, checksumValue);
                }
                else {
                    body = fileData;
                }
            }
            const request = new HttpRequest({
                method: serialized.method,
                protocol: serialized.protocol,
                hostname: serialized.hostname,
                port: serialized.port,
                path: serialized.path,
                query: serialized.query,
                headers: serialized.headers,
                body,
            });
            const { response } = await handler.handle(request);
            const chunks = [];
            if (response.body) {
                for await (const chunk of response.body) {
                    chunks.push(typeof chunk === "string" ? Buffer.from(chunk) : chunk);
                }
            }
            let responseBody;
            const transferList = [];
            if (chunks.length > 0) {
                const concatenated = Buffer.concat(chunks);
                const ab = new ArrayBuffer(concatenated.byteLength);
                new Uint8Array(ab).set(concatenated);
                responseBody = new Uint8Array(ab);
                transferList.push(ab);
            }
            port.postMessage({
                type: "httpResponse",
                id,
                response: {
                    statusCode: response.statusCode,
                    headers: response.headers,
                    body: responseBody,
                },
            }, transferList);
        }
        catch (err) {
            port.postMessage({
                type: "httpError",
                id,
                error: err.message ?? String(err),
                code: err.code,
                name: err.name,
            });
        }
    };
    port.on("message", (msg) => {
        if (msg.type === "done") {
            handler?.destroy();
            process.exit(0);
            return;
        }
        if (msg.type === "config") {
            const { maxSockets } = msg;
            handler = new NodeHttpHandler({
                httpsAgent: new Agent({ maxSockets, keepAlive: true }),
            });
            return;
        }
        if (msg.type === "httpRequestFromFile" || msg.type === "httpRequestFromRAM") {
            processRequest(msg);
        }
    });
    port.postMessage({ type: "ready" });
}
