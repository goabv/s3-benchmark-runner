const { S3TransferManager } = require("@aws-sdk/lib-transfer-manager/transfer-manager");
exports.S3TransferManager = S3TransferManager;
