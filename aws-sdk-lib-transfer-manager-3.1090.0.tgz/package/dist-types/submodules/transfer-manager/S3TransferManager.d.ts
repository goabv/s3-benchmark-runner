import type { GetObjectCommandInput } from "@aws-sdk/client-s3";
import type { StreamingBlobPayloadOutputTypes } from "@smithy/types";
import type { AddEventListenerOptions, EventListener, RemoveEventListenerOptions } from "./event-listener-types";
import type { DownloadDirectoryRequest, DownloadDirectoryResponse, DownloadRequest, DownloadResponse, IS3TransferManager, S3TransferManagerConfig, TransferCompleteEvent, TransferEvent, TransferOptions, UploadDirectoryRequest, UploadDirectoryResponse, UploadRequest, UploadResponse } from "./types";
/**
 * Client for efficient transfer of objects to and from Amazon S3.
 * Provides methods to optimize uploading and downloading individual objects
 * as well as entire directories, with support for multipart operations,
 * concurrency control, and request cancellation.
 * Implements an eventTarget-based progress tracking system with methods to register,
 * dispatch, and remove listeners for transfer lifecycle events.
 *
 * @alpha
 */
export declare class S3TransferManager implements IS3TransferManager {
    private static MIN_PART_SIZE;
    private readonly s3;
    private readonly targetPartSizeBytes;
    private readonly multipartUploadThresholdBytes;
    private readonly requestChecksumCalculation;
    private readonly responseChecksumValidation;
    private readonly multipartDownloadType;
    private readonly eventListeners;
    private readonly abortCleanupFunctions;
    private readonly maxConcurrentDownloads;
    private readonly maxConcurrentUploads;
    private readonly workerThreadCount;
    private readonly workerHttpHandler;
    private readonly logger;
    constructor(config?: S3TransferManagerConfig);
    /**
     * Registers a callback function to be executed when a specific transfer event occurs.
     * Supports monitoring the full lifecycle of transfers.
     *
     * @param type - The type of event to listen for.
     * @param callback - Function to execute when the specified event occurs.
     * @param options - Optional configuration for event listener behavior.
     *
     * @alpha
     */
    addEventListener(type: "transferInitiated", callback: EventListener<TransferEvent>, options?: AddEventListenerOptions | boolean): void;
    addEventListener(type: "bytesTransferred", callback: EventListener<TransferEvent>, options?: AddEventListenerOptions | boolean): void;
    addEventListener(type: "transferComplete", callback: EventListener<TransferCompleteEvent>, options?: AddEventListenerOptions | boolean): void;
    addEventListener(type: "transferFailed", callback: EventListener<TransferEvent>, options?: AddEventListenerOptions | boolean): void;
    addEventListener(type: string, callback: EventListener, options?: AddEventListenerOptions | boolean): void;
    /**
     * Dispatches an event to the registered event listeners.
     * Triggers callbacks registered via addEventListener with matching event types.
     *
     * @param event - The event object to dispatch.
     * @returns whether the event ran to completion
     *
     * @alpha
     */
    dispatchEvent(event: Event & TransferEvent): boolean;
    dispatchEvent(event: Event & TransferCompleteEvent): boolean;
    dispatchEvent(event: Event): boolean;
    /**
     * Removes a previously registered event listener from the specified event type.
     * Stops the callback from being invoked when the event occurs.
     *
     * @param type - The type of event to stop listening for.
     * @param callback - The function that was previously registered.
     * @param options - Optional configuration for the event listener.
     *
     * @alpha
     */
    removeEventListener(type: "transferInitiated", callback: EventListener<TransferEvent>, options?: RemoveEventListenerOptions | boolean): void;
    removeEventListener(type: "bytesTransferred", callback: EventListener<TransferEvent>, options?: RemoveEventListenerOptions | boolean): void;
    removeEventListener(type: "transferComplete", callback: EventListener<TransferCompleteEvent>, options?: RemoveEventListenerOptions | boolean): void;
    removeEventListener(type: "transferFailed", callback: EventListener<TransferEvent>, options?: RemoveEventListenerOptions | boolean): void;
    removeEventListener(type: string, callback: EventListener, options?: RemoveEventListenerOptions | boolean): void;
    /**
     * Uploads objects to S3 with automatic multipart upload handling.
     * Automatically chooses between single object upload or multipart upload based on content length threshold.
     *
     * @param request - PutObjectCommandInput and CreateMultipartUploadCommandInput parameters for single or multipart uploads.
     * @param transferOptions - Optional abort signal and event listeners for transfer lifecycle monitoring.
     *
     * @returns S3 PutObject or CompleteMultipartUpload response with transfer event dispatching.
     *
     */
    upload(request: UploadRequest, transferOptions?: TransferOptions): Promise<UploadResponse>;
    /**
     * Downloads single objects from S3 with automatic multipart handling.
     * Automatically chooses between PART or RANGE download strategies and joins streams into a single response.
     *
     * @param request - GetObjectCommandInput parameters. PartNumber is not supported - use GetObjectCommand directly for specific parts.
     * @param transferOptions - Optional abort signal and event listeners for transfer lifecycle monitoring.
     *
     * @returns S3 GetObject response with joined Body stream and transfer event dispatching.
     *
     * @alpha
     */
    download(request: DownloadRequest, transferOptions?: TransferOptions): Promise<DownloadResponse>;
    /**
     * Uploads files in a directory to an S3 bucket.
     * By default, it does not recurse into subdirectories. To upload recursively, set recursive: true.
     *
     * @param request - Configuration including bucket, source directory, filtering, failure handling, and transfer settings.
     * @param transferOptions - Allows users to specify cancel functions for the request and a collection of callbacks for monitoring transfer lifecycle events.
     *
     * @returns the number of objects that have been uploaded and the number of objects that have failed.
     *
     * @alpha
     */
    uploadDirectory(request: UploadDirectoryRequest, transferOptions?: TransferOptions): Promise<UploadDirectoryResponse>;
    /**
     * Downloads all objects in a bucket to a local directory.
     * Uses ListObjectsV2 to retrieve objects and automatically maps S3 object keys to local file paths.
     *
     * @param options - Configuration including bucket, destination directory, filtering, failure handling, and transfer settings.
     *
     * @returns The number of objects that have been downloaded and the number of objects that have failed.
     *
     * @alpha
     */
    downloadDirectory(request: DownloadDirectoryRequest, transferOptions?: TransferOptions): Promise<DownloadDirectoryResponse>;
    /**
     * Downloads object using part-based strategy with concurrent part requests.
     * Only initiates up to maxConcurrentDownloads requests in-flight, with new
     * requests triggered as previous ones complete.
     *
     * @internal
     */
    protected downloadByPart(request: DownloadRequest, transferOptions: TransferOptions, streams: Promise<StreamingBlobPayloadOutputTypes>[], requests: GetObjectCommandInput[], metadata: Omit<DownloadResponse, "Body">, checksumValidationEnabled: boolean): Promise<{
        totalSize: number | undefined;
        onStreamConsumed?: (index: number) => void;
    }>;
    /**
     * Downloads object using range-based strategy with lazy concurrent range requests.
     * Only initiates up to maxConcurrentDownloads requests in-flight, with new
     * requests triggered as previous ones complete — preventing idle connection timeouts.
     *
     * @internal
     */
    protected downloadByRange(request: DownloadRequest, transferOptions: TransferOptions, streams: Promise<StreamingBlobPayloadOutputTypes>[], requests: GetObjectCommandInput[], metadata: Omit<DownloadResponse, "Body">, checksumValidationEnabled: boolean): Promise<{
        totalSize: number | undefined;
        onStreamConsumed?: (index: number) => void;
    }>;
    /**
     * Adds all event listeners from provided collection to the transfer manager.
     *
     * @internal
     */
    private addEventListeners;
    /**
     * Removes event listeners from provided collection from the transfer manager.
     *
     * @internal
     */
    private removeEventListeners;
    /**
     * Copies all response properties except Body to the container object.
     *
     * @internal
     */
    private assignMetadata;
    /**
     * Updates response ContentLength and ContentRange based on total object size.
     *
     * @internal
     */
    private updateResponseLengthAndRange;
    /**
     * Clears checksum values for composite multipart downloads.
     *
     * @internal
     */
    private updateChecksumValues;
    /**
     * Processes response metadata by updating length, copying properties, and handling checksums.
     *
     * @internal
     */
    private processResponseMetadata;
    /**
     * Throws AbortError if the transfer has been aborted via signal.
     *
     * @internal
     */
    private checkAborted;
    /**
     * Validates if configuration parameters meets minimum requirements.
     *
     * @internal
     */
    private validateConfig;
    /**
     * Dispatches transferInitiated event with initial progress snapshot.
     *
     * @internal
     */
    private dispatchTransferInitiatedEvent;
    /**
     * Dispatches transferFailed event with error details and progress snapshot.
     *
     * @internal
     */
    private dispatchTransferFailedEvent;
    /**
     * Generator that yields event listeners from the provided collection for iteration.
     *
     * @internal
     */
    private iterateListeners;
    /**
     * Creates a concurrent task pool using a sliding window concurrency model.
     * Each task is a deferred S3 request (e.g., GetObject for part/range downloads) that returns a promise.
     * It seeds up to `maxConcurrent` tasks initially. When a stream is fully consumed by the caller,
     * the `onStreamConsumed` callback launches the next pending task, keeping at most `maxConcurrent`
     * requests in-flight at any time.
     *
     * @param tasks - Array of deferred task functions, each returning a promise.
     * @param maxConcurrent - Maximum number of HTTP requests in-flight at any time.
     * @returns An object containing the array of promises (one per task) and an `onStreamConsumed` callback
     *          to signal that a stream has been consumed and the next task can be launched.
     *
     * @internal
     */
    private createConcurrentTaskPool;
    /**
     * Validates part download ContentRange matches expected part boundaries.
     *
     * @internal
     */
    private validatePartDownload;
    /**
     * Validates range download ContentRange matches requested byte range.
     *
     * @internal
     */
    private validateRangeDownload;
    /**
     * Uploads a single object to S3 using PutObject operation.
     * Used when content length is below the multipart upload threshold.
     *
     * @internal
     */
    private uploadSinglePart;
    /**
     * Calculates part size and expected parts count.
     *
     * @internal
     */
    private calculatePartSize;
    /**
     * Checks if the body is a file read stream with a .path property.
     * @internal
     */
    private isFileBody;
    /**
     * Checks if the body is fully in memory (Buffer, Uint8Array, or string).
     * @internal
     */
    private isInMemoryBody;
    /**
     * Uploads using worker threads from a file source. Workers read file slices
     * directly from disk, compute checksum, and send data in aws-chunked format
     * with trailing checksums.
     *
     * @internal
     */
    private threadedUploadInPartsFromFile;
    /**
     * Uploads using worker threads with in-memory data. Copies the user's Buffer
     * into a SharedArrayBuffer once, then workers read slices by offset —
     * zero-copy per part.
     *
     * @internal
     */
    private threadedUploadInParts;
    /**
     * Common implementation for threaded multipart uploads.
     * Handles CreateMPU, concurrent UploadPart dispatch, and CompleteMPU/AbortMPU.
     * The buildDataSource factory is called with checksum info to produce the
     * per-request data source passed to the WorkerHttpHandler.
     *
     * @internal
     */
    private threadedMultipartUpload;
    /**
     * Uploads an object to S3 using multipart upload operation.
     * Used when content length exceeds the multipart upload threshold.
     * Streams the body chunk-by-chunk via getChunk without buffering
     * the entire content into memory.
     *
     * @internal
     */
    private uploadInParts;
    /**
     * Async generator that yields file paths from the source directory.
     * Uses fs.opendir with recursive option (Node 20+).
     * Handles symlink cycle detection when followSymbolicLinks is true.
     *
     * @internal
     */
    private traverseDirectory;
    /**
     * Derives the S3 object key from local file path.
     * Computes relative path from source, normalizes separators to "/",
     * and prepends s3Prefix if provided.
     *
     * @internal
     */
    private deriveS3Key;
    /**
     * Validates that a data part has a measurable size and matches the expected part size.
     *
     * @internal
     */
    private validateUploadPart;
}
/**
 * Internal event handler for download lifecycle hooks.
 *
 * @internal
 */
export declare const internalEventHandler: {
    afterInitialGetObject(): Promise<void>;
};
