/**
 * Browser stub for worker-http-handler.
 * Worker threads are not available in browser environments.
 * @internal
 */
export type DataSource = any;
export declare function defaultWorkerCount(): number;
export declare function createEmptyReadable(): any;
export declare class WorkerHttpHandler {
    constructor();
    handle(): Promise<any>;
    updateHttpClientConfig(): void;
    httpHandlerConfigs(): Record<string, unknown>;
    destroy(): void;
}
