import type { Logger } from "@smithy/types";
export declare class LogLevel implements Logger {
    private minimum;
    private logger;
    private static LEVELS;
    private readonly level;
    constructor(minimum: keyof Logger, logger?: Logger);
    trace(...args: any[]): void;
    debug(...args: any[]): void;
    info(...args: any[]): void;
    warn(...args: any[]): void;
    error(...args: any[]): void;
}
