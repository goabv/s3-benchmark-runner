import type { StreamingBlobPayloadOutputTypes } from "@smithy/types";
import type { JoinStreamIterationEvents } from "./types";
/**
 * Joins multiple stream promises into a single stream with event callbacks.
 *
 * @internal
 */
export declare function joinStreams(streams: Promise<StreamingBlobPayloadOutputTypes>[], eventListeners?: JoinStreamIterationEvents): Promise<StreamingBlobPayloadOutputTypes>;
/**
 * Iterates through stream promises sequentially, yielding chunks with progress tracking.
 *
 * @internal
 */
export declare function iterateStreams(promises: Promise<StreamingBlobPayloadOutputTypes>[], eventListeners?: JoinStreamIterationEvents): AsyncIterable<Uint8Array, void, void>;
