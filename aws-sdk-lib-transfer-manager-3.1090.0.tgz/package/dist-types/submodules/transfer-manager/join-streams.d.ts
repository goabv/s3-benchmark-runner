import type { StreamingBlobPayloadOutputTypes } from "@smithy/types";
import type { JoinStreamIterationEvents } from "./types";
/**
 * Joins multiple stream promises into a single stream with event callbacks.
 *
 * @internal
 */
export declare function joinStreams(streams: Promise<StreamingBlobPayloadOutputTypes>[], eventListeners?: JoinStreamIterationEvents): Promise<StreamingBlobPayloadOutputTypes>;
/**
 * Iterates through stream promises sequentially, yielding chunks with progress tracking.
 *
 * @internal
 */
export declare function iterateStreams(promises: Promise<StreamingBlobPayloadOutputTypes>[], eventListeners?: JoinStreamIterationEvents): AsyncIterable<StreamingBlobPayloadOutputTypes, void, void>;
/**
 * Destroys/cancels a set of stream promises, swallowing any errors.
 *
 * Used to clean up response bodies that were received but never fully consumed
 * (for example when a transfer is aborted). A no-op "error" handler is attached
 * to Node streams before destroying so that a socket-level error raised while
 * tearing down an unconsumed response body (e.g. "aborted"/ECONNRESET) does not
 * surface as an uncaught exception.
 *
 * @internal
 */
export declare function destroyStreams(promises: Promise<StreamingBlobPayloadOutputTypes>[]): Promise<void>;
