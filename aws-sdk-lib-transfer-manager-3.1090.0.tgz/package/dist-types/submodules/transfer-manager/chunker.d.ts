export interface RawDataPart {
    partNumber: number;
    data: Uint8Array;
    lastPart?: boolean;
}
export declare const byteLength: (input: any) => number | undefined;
export declare const getChunk: (data: any, partSize: number) => AsyncGenerator<RawDataPart, void, undefined>;
