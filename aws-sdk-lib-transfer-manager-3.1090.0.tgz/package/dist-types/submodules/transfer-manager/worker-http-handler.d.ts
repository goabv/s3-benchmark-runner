/**
 * HTTP handler that delegates signed HTTP requests to a pool of worker threads.
 *
 * For UploadPart requests with a file source, the handler forwards the signed
 * headers (including aws-chunked encoding headers) and file offset info to a
 * worker. The worker reads the file slice, computes CRC32, and sends the data
 * in aws-chunked format with a trailing checksum — fulfilling the contract
 * that the checksum middleware set up on the main thread.
 *
 * @internal
 */
import { HttpResponse } from "@smithy/core/protocols";
import type { HttpHandlerOptions, HttpRequest, HttpResponse as HttpResponseShape } from "@smithy/types";
import { Readable } from "node:stream";
/**
 * Creates an empty Readable stream that immediately ends.
 * Used as a placeholder body for UploadPart in threaded uploads.
 * @internal
 */
export declare function createEmptyReadable(): Readable;
/**
 * Serializable subset of HttpRequest.
 * @internal
 */
export interface WorkerHttpRequest extends Omit<HttpRequest, "body"> {
    body?: Uint8Array;
}
/**
 * Serializable subset of HttpResponse.
 * @internal
 */
export interface WorkerHttpResponse extends Omit<HttpResponseShape, "body"> {
    body?: Uint8Array;
}
interface BaseHttpWorkerRequestMessage {
    id: number;
    request: WorkerHttpRequest;
}
export interface HttpWorkerFileRequestMessage extends BaseHttpWorkerRequestMessage {
    type: "httpRequestFromFile";
    filePath: string;
    offset: number;
    length: number;
    checksumAlgorithm?: string;
    checksumHeader?: string;
}
export interface HttpWorkerRAMRequestMessage extends BaseHttpWorkerRequestMessage {
    type: "httpRequestFromRAM";
    sharedBuffer: SharedArrayBuffer;
    offset: number;
    length: number;
    checksumAlgorithm?: string;
    checksumHeader?: string;
}
export type HttpWorkerRequestMessage = HttpWorkerFileRequestMessage | HttpWorkerRAMRequestMessage;
export interface HttpWorkerConfigMessage {
    type: "config";
    maxSockets: number;
}
export interface HttpWorkerDoneMessage {
    type: "done";
}
export type HttpWorkerInboundMessage = HttpWorkerRequestMessage | HttpWorkerConfigMessage | HttpWorkerDoneMessage;
export interface HttpWorkerResponseMessage {
    type: "httpResponse";
    id: number;
    response: WorkerHttpResponse;
}
export interface HttpWorkerErrorMessage {
    type: "httpError";
    id: number;
    error: string;
    code?: string;
    name?: string;
}
export interface HttpWorkerReadyMessage {
    type: "ready";
}
export type HttpWorkerOutboundMessage = HttpWorkerResponseMessage | HttpWorkerErrorMessage | HttpWorkerReadyMessage;
/** @internal */
export declare function defaultWorkerCount(): number;
/** @internal */
export interface FileSource {
    type: "file";
    filePath: string;
    partSize: number;
    totalFileSize: number;
    checksumAlgorithm?: string;
    checksumHeader?: string;
}
/** @internal */
export interface SharedBufferSource {
    type: "sharedBuffer";
    sharedBuffer: SharedArrayBuffer;
    partSize: number;
    totalSize: number;
    checksumAlgorithm?: string;
    checksumHeader?: string;
}
/**
 * Data source passed per-request to handle().
 * Tells the worker where to read the body from.
 * @internal
 */
export type DataSource = FileSource | SharedBufferSource;
/**
 * Options for WorkerHttpHandler.handle() that extend standard HttpHandlerOptions
 * with an optional data source for UploadPart requests.
 * @internal
 */
export interface WorkerHttpHandlerOptions extends HttpHandlerOptions {
    dataSource?: DataSource;
}
export declare class WorkerHttpHandler {
    private workers;
    private inflightRequests;
    private nextRequestId;
    private workerInflightCounts;
    private workerThreadCount;
    private maxConcurrentUploads;
    private initialized;
    private initPromise;
    private fallbackHandler;
    readonly metadata: {
        handlerProtocol: string;
    };
    constructor(options?: {
        workerThreadCount?: number;
        maxConcurrentUploads?: number;
    });
    /**
     * Returns the worker script file path.
     */
    private resolveWorkerConfig;
    private ensureInitialized;
    /**
     * Returns the index of the worker with the fewest in-flight requests.
     */
    private pickWorkerIndex;
    /**
     * Dispatches a message to the least-busy worker and tracks the in-flight count.
     */
    private dispatchToWorker;
    private extractPartNumber;
    handle(request: HttpRequest, options?: WorkerHttpHandlerOptions): Promise<{
        response: HttpResponse;
    }>;
    updateHttpClientConfig(_key: string, _value: unknown): void;
    httpHandlerConfigs(): Record<string, unknown>;
    destroy(): void;
}
export {};
