import type { CannedFailurePolicy, DirectoryTransferFailureContext, FailurePolicy } from "./types";
/**
 * Weighted semaphore with a soft concurrency limit.
 * Allows a job to start if in-flight weight is below the limit, even if
 * that job pushes the total over. New jobs are paused until it drops back.
 *
 * @internal
 */
export declare class Semaphore {
    private readonly limit;
    private inFlightRequests;
    private waiters;
    constructor(limit: number);
    acquire(count?: number): Promise<void>;
    release(count?: number): void;
}
/**
 * Validates that a path exists and is a directory.
 * Resolves to absolute path.
 *
 * @param dirPath - The directory path to validate.
 *
 * @throws Error - If the path does not exist.
 * @throws Error - If the path is not a directory.
 *
 * @internal
 */
export declare function validateDirectory(dirPath: string): Promise<string>;
/**
 * Executes the failure policy for a failed transfer (upload or download).
 *
 * @param policy - The failure policy to execute (canned or custom callback).
 * @param context - The failure context containing the directory request, failed object request, and error.
 * @param abortController - Controller to signal abort to all in-flight operations on terminate.
 *
 * @internal
 */
export declare function handleFailure(policy: FailurePolicy, context: DirectoryTransferFailureContext, abortController: AbortController): Promise<CannedFailurePolicy>;
