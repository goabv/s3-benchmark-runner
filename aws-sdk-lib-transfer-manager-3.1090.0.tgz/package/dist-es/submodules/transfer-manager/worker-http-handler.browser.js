export function defaultWorkerCount() {
    return 1;
}
export function createEmptyReadable() {
    throw new Error("WorkerHttpHandler is not supported in browser environments.");
}
export class WorkerHttpHandler {
    constructor() {
        throw new Error("WorkerHttpHandler is not supported in browser environments.");
    }
    async handle() {
        throw new Error("WorkerHttpHandler is not supported in browser environments.");
    }
    updateHttpClientConfig() { }
    httpHandlerConfigs() {
        return {};
    }
    destroy() { }
}
