import { isReadableStream, sdkStreamMixin } from "@smithy/core/serde";
export async function joinStreams(streams, eventListeners) {
    const firstStream = await streams[0];
    if (isReadableStream(firstStream) || firstStream instanceof Blob) {
        const newReadableStream = new ReadableStream({
            async start(controller) {
                for await (const chunk of iterateStreams(streams, eventListeners)) {
                    controller.enqueue(chunk);
                }
                controller.close();
            },
        });
        return sdkStreamMixin(newReadableStream);
    }
    else {
        throw new Error("Unsupported Stream Type");
    }
}
export async function* iterateStreams(promises, eventListeners) {
    let bytesTransferred = 0;
    let index = 0;
    for (const streamPromise of promises) {
        let stream;
        try {
            stream = await streamPromise;
        }
        catch (e) {
            await destroy(promises);
            eventListeners?.onFailure?.(e, index);
            throw e;
        }
        if (isReadableStream(stream)) {
            const reader = stream.getReader();
            try {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        break;
                    }
                    yield value;
                    bytesTransferred += value.byteLength;
                    eventListeners?.onBytes?.(bytesTransferred, index);
                }
            }
            catch (e) {
                reader.releaseLock();
                await destroy(promises);
                eventListeners?.onFailure?.(e, index);
                throw e;
            }
            finally {
                reader.releaseLock();
            }
        }
        else if (stream instanceof Blob) {
            const blobStream = stream.stream();
            const reader = blobStream.getReader();
            try {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        break;
                    }
                    yield value;
                    bytesTransferred += value.byteLength;
                    eventListeners?.onBytes?.(bytesTransferred, index);
                }
            }
            catch (e) {
                await destroy(promises);
                eventListeners?.onFailure?.(e, index);
                throw e;
            }
            finally {
                reader.releaseLock();
            }
        }
        else {
            await destroy(promises);
            const failure = new Error(`unhandled stream type ${stream?.constructor?.name}`);
            eventListeners?.onFailure?.(failure, index);
            throw failure;
        }
        eventListeners?.onStreamConsumed?.(index);
        index++;
    }
    eventListeners?.onCompletion?.(bytesTransferred, index - 1);
}
async function destroy(promises) {
    await Promise.all(promises.map(async (streamPromise) => {
        return streamPromise
            .then((stream) => {
            if (isReadableStream(stream)) {
                return stream.cancel();
            }
        })
            .catch((e) => { });
    }));
}
