import { Buffer } from "buffer";
import { lstatSync, ReadStream } from "node:fs";
export const byteLength = (input) => {
    if (input == null) {
        return 0;
    }
    if (typeof input === "string") {
        return Buffer.byteLength(input);
    }
    if (typeof input.byteLength === "number") {
        return input.byteLength;
    }
    else if (typeof input.length === "number") {
        return input.length;
    }
    else if (typeof input.size === "number") {
        return input.size;
    }
    else if (typeof input.start === "number" && typeof input.end === "number") {
        return input.end + 1 - input.start;
    }
    else if (input instanceof ReadStream) {
        try {
            return lstatSync(input.path).size;
        }
        catch {
            return undefined;
        }
    }
    return undefined;
};
async function* getChunkStream(data, partSize, getNextData) {
    let partNumber = 1;
    const currentBuffer = { chunks: [], length: 0 };
    for await (const datum of getNextData(data)) {
        currentBuffer.chunks.push(datum);
        currentBuffer.length += datum.byteLength;
        while (currentBuffer.length > partSize) {
            const dataChunk = currentBuffer.chunks.length > 1 ? Buffer.concat(currentBuffer.chunks) : currentBuffer.chunks[0];
            yield { partNumber, data: dataChunk.subarray(0, partSize) };
            currentBuffer.chunks = [dataChunk.subarray(partSize)];
            currentBuffer.length = currentBuffer.chunks[0].byteLength;
            partNumber += 1;
        }
    }
    yield {
        partNumber,
        data: currentBuffer.chunks.length !== 1 ? Buffer.concat(currentBuffer.chunks) : currentBuffer.chunks[0],
        lastPart: true,
    };
}
async function* getChunkUint8Array(data, partSize) {
    let partNumber = 1;
    let startByte = 0;
    let endByte = partSize;
    while (endByte < data.byteLength) {
        yield { partNumber, data: data.subarray(startByte, endByte) };
        partNumber += 1;
        startByte = endByte;
        endByte = startByte + partSize;
    }
    yield { partNumber, data: data.subarray(startByte), lastPart: true };
}
async function* getDataReadable(data) {
    for await (const chunk of data) {
        if (Buffer.isBuffer(chunk) || chunk instanceof Uint8Array) {
            yield chunk;
        }
        else {
            yield Buffer.from(chunk);
        }
    }
}
async function* getDataReadableStream(data) {
    const reader = data.getReader();
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                return;
            if (Buffer.isBuffer(value) || value instanceof Uint8Array) {
                yield value;
            }
            else {
                yield Buffer.from(value);
            }
        }
    }
    finally {
        reader.releaseLock();
    }
}
export const getChunk = (data, partSize) => {
    if (data instanceof Uint8Array) {
        return getChunkUint8Array(data, partSize);
    }
    if (data instanceof String || typeof data === "string") {
        return getChunkUint8Array(Buffer.from(data), partSize);
    }
    if (data instanceof ReadableStream) {
        return getChunkStream(data, partSize, getDataReadableStream);
    }
    if (typeof data.stream === "function") {
        return getChunkStream(data.stream(), partSize, getDataReadableStream);
    }
    if (Symbol.asyncIterator in data || typeof data[Symbol.asyncIterator] === "function") {
        return getChunkStream(data, partSize, getDataReadable);
    }
    throw new Error("Body Data is unsupported format, expected data to be one of: string | Uint8Array | Buffer | Readable | ReadableStream | Blob;.");
};
