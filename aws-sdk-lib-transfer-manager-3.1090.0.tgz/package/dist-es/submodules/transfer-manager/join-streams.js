import { isReadableStream, sdkStreamMixin } from "@smithy/core/serde";
import { Readable } from "node:stream";
export async function joinStreams(streams, eventListeners) {
    const firstStream = await streams[0];
    if (isReadableStream(firstStream)) {
        const newReadableStream = new ReadableStream({
            async start(controller) {
                for await (const chunk of iterateStreams(streams, eventListeners)) {
                    controller.enqueue(chunk);
                }
                controller.close();
            },
        });
        return sdkStreamMixin(newReadableStream);
    }
    else {
        streams.forEach((stream) => stream?.catch(() => { }));
        return sdkStreamMixin(Readable.from(iterateStreams(streams, eventListeners)));
    }
}
export async function* iterateStreams(promises, eventListeners) {
    for (const p of promises) {
        p?.catch(() => { });
    }
    let bytesTransferred = 0;
    let index = 0;
    for (const streamPromise of promises) {
        if (!streamPromise) {
            throw new Error("Stream promise is undefined - lazy prefetch may not have completed");
        }
        let stream;
        try {
            stream = await streamPromise;
        }
        catch (e) {
            await destroyStreams(promises);
            eventListeners?.onFailure?.(e, index);
            throw e;
        }
        if (isReadableStream(stream)) {
            const reader = stream.getReader();
            try {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        break;
                    }
                    yield value;
                    bytesTransferred += value.byteLength;
                    eventListeners?.onBytes?.(bytesTransferred, index);
                }
            }
            catch (e) {
                await destroyStreams(promises);
                eventListeners?.onFailure?.(e, index);
                throw e;
            }
            finally {
                reader.releaseLock();
            }
        }
        else if (stream instanceof Readable) {
            try {
                for await (const chunk of stream) {
                    yield chunk;
                    const chunkSize = Buffer.isBuffer(chunk) ? chunk.length : Buffer.byteLength(chunk);
                    bytesTransferred += chunkSize;
                    eventListeners?.onBytes?.(bytesTransferred, index);
                }
            }
            catch (e) {
                await destroyStreams(promises);
                eventListeners?.onFailure?.(e, index);
                throw e;
            }
        }
        else {
            await destroyStreams(promises);
            const failure = new Error(`unhandled stream type ${stream?.constructor?.name}`);
            eventListeners?.onFailure?.(failure, index);
            throw failure;
        }
        eventListeners?.onStreamConsumed?.(index);
        index++;
    }
    eventListeners?.onCompletion?.(bytesTransferred, index - 1);
}
export async function destroyStreams(promises) {
    await Promise.all(promises.map(async (streamPromise) => {
        if (!streamPromise)
            return;
        return streamPromise
            .then((stream) => {
            if (stream instanceof Readable) {
                stream.on("error", () => { });
                stream.destroy();
                return;
            }
            else if (isReadableStream(stream)) {
                return stream.cancel();
            }
        })
            .catch((e) => { });
    }));
}
