import { HttpResponse } from "@smithy/core/protocols";
import { NodeHttpHandler } from "@smithy/node-http-handler";
import { existsSync } from "node:fs";
import { cpus } from "node:os";
import * as path from "node:path";
import { Readable } from "node:stream";
import { Worker } from "node:worker_threads";
export function createEmptyReadable() {
    return new Readable({
        read() {
            this.push(null);
        },
    });
}
export function defaultWorkerCount() {
    return cpus().length;
}
export class WorkerHttpHandler {
    workers = [];
    inflightRequests = new Map();
    nextRequestId = 0;
    workerInflightCounts = [];
    workerThreadCount;
    maxConcurrentUploads;
    initialized = false;
    initPromise;
    fallbackHandler;
    metadata = { handlerProtocol: "http/1.1" };
    constructor(options) {
        this.workerThreadCount = options?.workerThreadCount ?? defaultWorkerCount();
        this.maxConcurrentUploads = options?.maxConcurrentUploads ?? 32;
        this.fallbackHandler = new NodeHttpHandler();
    }
    resolveWorkerConfig() {
        const submodulePath = path.join(__dirname, "..", "worker", "index.js");
        if (existsSync(submodulePath)) {
            return { workerPath: submodulePath };
        }
        const tsPath = path.join(__dirname, "..", "worker", "index.ts");
        if (existsSync(tsPath)) {
            return { workerPath: tsPath, workerOptions: { execArgv: ["--require", "tsx/cjs"] } };
        }
        return { workerPath: submodulePath };
    }
    ensureInitialized() {
        if (this.initialized)
            return Promise.resolve();
        if (this.initPromise)
            return this.initPromise;
        this.initPromise = new Promise((resolve, reject) => {
            const { workerPath, workerOptions } = this.resolveWorkerConfig();
            let readyCount = 0;
            let errorCount = 0;
            let settled = false;
            this.workerInflightCounts = new Array(this.workerThreadCount).fill(0);
            for (let i = 0; i < this.workerThreadCount; i++) {
                const worker = new Worker(workerPath, workerOptions);
                this.workers.push(worker);
                const workerIndex = i;
                worker.on("message", (msg) => {
                    if (msg.type === "ready") {
                        worker.postMessage({
                            type: "config",
                            maxSockets: Math.max(50, this.maxConcurrentUploads),
                        });
                        readyCount++;
                        if (!settled && readyCount === this.workerThreadCount) {
                            settled = true;
                            this.initialized = true;
                            resolve();
                        }
                        return;
                    }
                    if (msg.type === "httpResponse") {
                        const pending = this.inflightRequests.get(msg.id);
                        this.inflightRequests.delete(msg.id);
                        if (pending) {
                            this.workerInflightCounts[pending.workerIndex]--;
                            pending.resolve({
                                response: new HttpResponse({
                                    statusCode: msg.response.statusCode,
                                    headers: msg.response.headers,
                                    body: msg.response.body,
                                }),
                            });
                        }
                        return;
                    }
                    if (msg.type === "httpError") {
                        const pending = this.inflightRequests.get(msg.id);
                        this.inflightRequests.delete(msg.id);
                        if (pending) {
                            this.workerInflightCounts[pending.workerIndex]--;
                            const error = Object.assign(new Error(msg.error), {
                                ...(msg.code && { code: msg.code }),
                                ...(msg.name && { name: msg.name }),
                            });
                            pending.reject(error);
                        }
                        return;
                    }
                });
                worker.on("error", (err) => {
                    if (!settled) {
                        errorCount++;
                        if (errorCount + readyCount === this.workerThreadCount) {
                            settled = true;
                            this.initPromise = undefined;
                            reject(new Error(`Failed to initialize worker threads: ${err.message}`));
                        }
                    }
                    for (const [id, pending] of this.inflightRequests) {
                        if (pending.workerIndex === workerIndex) {
                            pending.reject(err);
                            this.inflightRequests.delete(id);
                        }
                    }
                    this.workerInflightCounts[workerIndex] = Infinity;
                });
            }
        });
        return this.initPromise;
    }
    pickWorkerIndex() {
        let minIndex = 0;
        for (let i = 1; i < this.workerInflightCounts.length; i++) {
            if (this.workerInflightCounts[i] < this.workerInflightCounts[minIndex]) {
                minIndex = i;
            }
        }
        return minIndex;
    }
    dispatchToWorker(id, message) {
        const workerIndex = this.pickWorkerIndex();
        this.workerInflightCounts[workerIndex]++;
        return new Promise((resolve, reject) => {
            this.inflightRequests.set(id, { resolve, reject, workerIndex });
            this.workers[workerIndex].postMessage(message);
        });
    }
    extractPartNumber(request) {
        const partNumber = request.query?.partNumber;
        if (partNumber) {
            return Number(Array.isArray(partNumber) ? partNumber[0] : partNumber);
        }
        return undefined;
    }
    async handle(request, options) {
        const dataSource = options?.dataSource;
        const partNumber = this.extractPartNumber(request);
        if (!dataSource || !partNumber) {
            return this.fallbackHandler.handle(request, options);
        }
        await this.ensureInitialized();
        const id = this.nextRequestId++;
        const serializedRequest = {
            method: request.method,
            protocol: request.protocol,
            hostname: request.hostname,
            port: request.port,
            path: request.path,
            query: request.query,
            headers: request.headers,
        };
        if (dataSource.type === "file") {
            const { filePath, partSize, totalFileSize, checksumAlgorithm, checksumHeader } = dataSource;
            const offset = (partNumber - 1) * partSize;
            const length = Math.min(partSize, totalFileSize - offset);
            const message = {
                type: "httpRequestFromFile",
                id,
                request: serializedRequest,
                filePath,
                offset,
                length,
                checksumAlgorithm,
                checksumHeader,
            };
            return this.dispatchToWorker(id, message);
        }
        const { sharedBuffer, partSize, totalSize, checksumAlgorithm, checksumHeader } = dataSource;
        const offset = (partNumber - 1) * partSize;
        const length = Math.min(partSize, totalSize - offset);
        const message = {
            type: "httpRequestFromRAM",
            id,
            request: serializedRequest,
            sharedBuffer,
            offset,
            length,
            checksumAlgorithm,
            checksumHeader,
        };
        return this.dispatchToWorker(id, message);
    }
    updateHttpClientConfig(_key, _value) { }
    httpHandlerConfigs() {
        return {};
    }
    destroy() {
        for (const worker of this.workers) {
            worker.postMessage({ type: "done" });
        }
        this.workers = [];
        this.workerInflightCounts = [];
        this.initialized = false;
        this.initPromise = undefined;
        this.fallbackHandler.destroy();
    }
}
