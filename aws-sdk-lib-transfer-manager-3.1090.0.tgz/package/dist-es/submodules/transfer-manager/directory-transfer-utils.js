import { stat } from "node:fs/promises";
import { resolve } from "node:path";
export class Semaphore {
    limit;
    inFlightRequests = 0;
    waiters = [];
    constructor(limit) {
        this.limit = limit;
    }
    async acquire(count = 1) {
        if (this.inFlightRequests < this.limit) {
            this.inFlightRequests += count;
            return;
        }
        await new Promise((resolve) => this.waiters.push(resolve));
        this.inFlightRequests += count;
    }
    release(count = 1) {
        this.inFlightRequests -= count;
        while (this.waiters.length > 0 && this.inFlightRequests < this.limit) {
            const next = this.waiters.shift();
            if (next) {
                next();
            }
        }
    }
}
export async function validateDirectory(dirPath) {
    const absolutePath = resolve(dirPath);
    let stats;
    try {
        stats = await stat(absolutePath);
    }
    catch (error) {
        throw new Error(`Cannot access directory at: ${absolutePath}, ${error.message}`);
    }
    if (!stats.isDirectory()) {
        throw new Error(`Path is not a directory: ${absolutePath}`);
    }
    return absolutePath;
}
export async function handleFailure(policy, context, abortController) {
    if (policy === "terminate") {
        abortController.abort();
        return "terminate";
    }
    if (policy === "continue") {
        return "continue";
    }
    try {
        const result = await policy(context);
        if (result === "terminate") {
            abortController.abort();
        }
        return result;
    }
    catch {
        abortController.abort();
        return "terminate";
    }
}
