export class LogLevel {
    minimum;
    logger;
    static LEVELS = ["trace", "debug", "info", "warn", "error"];
    level = 5;
    constructor(minimum, logger = console) {
        this.minimum = minimum;
        this.logger = logger;
        const index = LogLevel.LEVELS.indexOf(minimum);
        if (index === -1) {
            throw new Error(`Log level must be one of ${LogLevel.LEVELS.join(", ")}`);
        }
        this.level = index;
    }
    trace(...args) {
        this.level <= 0 && this.logger.trace?.(...args);
    }
    debug(...args) {
        this.level <= 1 && this.logger.debug?.(...args);
    }
    info(...args) {
        this.level <= 2 && this.logger.info?.(...args);
    }
    warn(...args) {
        this.level <= 3 && this.logger.warn?.(...args);
    }
    error(...args) {
        this.level <= 4 && this.logger.error?.(...args);
    }
}
